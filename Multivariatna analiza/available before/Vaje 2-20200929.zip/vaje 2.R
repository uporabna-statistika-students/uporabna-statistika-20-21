#library("foreign")
library("e1071")
library("mclust")
library("cluster")
library("questionr") 
# install.packages("multiUS", repos="http://R-Forge.R-project.org")
library("multiUS")
library("blockmodeling")
#######################################################################################
#                            PRIPRAVA PODATKOV
#######################################################################################
# uvoz podatkov SPSS
# to so podatki, ki smo jih shranili na 
# privh vajah
load("ESS_SLO_rekodirane", verbose = TRUE)

tradicionalniViri <- c("premog", "plin", "voda", "jedrska")
alternativniViri  <- c("biomasa", "sonce", "veter")

viri <- c(tradicionalniViri, alternativniViri)

# uporabljali bomo samo enote, ki imajo vrednosti pri vseh spremenljivkah
com <- complete.cases(podatki[, viri])
viriData <- podatki[com, viri]
varLabs <- attributes(podatki)$variable.labels

#######################################################################################
#                            HIERARHICNO RAZVRSCANJE
#######################################################################################
# standardizirane vrednosti - z standardizacija 
SviriData <- scale(viriData)
# matrika razlicnosti - evklidska razdalja
d <- dist(SviriData, method="euc")
# kvadridana evklidska razdalja
d2 <- d^2

par(mfrow = c(2, 2))
# uporabimo metodo minimalna metoda ali enojna (single linkage) povzeanost
single <- hclust(d = d2, method= "single")
plot(single, hang = -1, main = "single\n(minimalna metoda)", ylab = "razdalja", xlab = "enote")

# uporabimo maksimalno metodo ali polno (complete linkage) povezanost 
complete <- hclust(d = d2, method = "complete")
plot(complete, hang = -1, main = "complete\n(maksimalna metoda)", ylab = "razdalja", xlab = "enote")

# uporabimo McQuittyjevo metodo ("povprecna" povzeanost)
mcquitty <- hclust(d = d2, method = "mcquitty")
plot(mcquitty, hang = -1, main = "mcquitty\n(povprecna metoda)", ylab = "razdalja", xlab = "enote")

# uporabimo wardovo metodo
ward <- hclust(d = d2, method = "ward.D")
plot(ward, hang = -1, main = "Ward\n(Wardova metoda)", ylab = "razdalja", xlab = "enote")

# shranimo rezultate razlicnih metod
# za stevilo skupin se odlocimo na podlagi dendrograma
singleK3 <- cutree(single, k = 3)
compK2 <- cutree(complete, k = 2)
compK3 <- cutree(complete, k = 3)
mcquittyK2 <- cutree(mcquitty, k = 2)
wardK2 <- cutree(ward, k = 2)
wardK3 <- cutree(ward, k = 3)

# izracunamo vrednosti Wardove kriterijske funkcije - manj je bolje
# primerjamo lahko samo razvrstitve z enakim stevilom skupin, saj 
# visanje stevila skupin v splosnem niza vrednost KF
# razlicne metode pogojno
wardKF(X = SviriData, clu = singleK3)
wardKF(X = SviriData, clu = compK2)
wardKF(X = SviriData, clu = compK3)
wardKF(X = SviriData, clu = mcquittyK2)
wardKF(X = SviriData, clu = wardK2)
wardKF(X = SviriData, clu = wardK3)

# pogledamo, koliko je enot po skupinah
table(singleK3) 
table(compK2)
table(compK3)
table(mcquittyK2)
table(wardK2)
table(wardK3)

# narisemo povprecja odgovorov po skupinah - nestandardizirani podatki in standardizirani podatki
# (za najboljso razvrstitev glede na Wardovo KF)
# namesto z argumentom "ylab" se lahko privzeto ime spremeni tudi v sami funkciji plotMeans
par(mfrow = c(1, 2), mar = c(10, 5, 1, 1))
plotMeans(viriData, by = wardK3, ylim = c(1, 6), plotLegend = FALSE, ylab = "povprecja\nnestandardiziranih spremenljivk", xlab = "", main = "Wardova")
plotMeans(SviriData, by= wardK3, ylim = c(-2, 2), plotLegend = FALSE, ylab = "povprecja\nstandardiziranih spremenljivk", xlab = "", main = "Wardova")

# primer izracuna silhuete
sis <- NULL
for (i in 2:10){
  si <- silhouette(cutree(ward, k = i), daisy(SviriData))
  sis[i] <- mean(si[,3])
}
plot(sis, type = "b", xlab = "stevilo skupin", ylab = "povprecna silhueta")
#######################################################################################
#                            NEHIERARHICNO RAZVRSCANJE
#######################################################################################
# http://shabal.in/visuals/kmeans/2.html

# k-means; stevilo skupin lahko dolocimo tudi na podlagi vsote kvadratov razdalij znotraj skupin
# vrednost bo vedno padala s stevilom skupin -> gledamo koleno 
# (ce ni kolena je to lahko indikator, da skupine niso jasno locene)
Kmax <- 12
kmCrit<-numeric(Kmax)
for(k in 1:Kmax){
  kmCrit[k] <- kmeans(x = SviriData, centers = k, nstart = 100, iter.max = 20)$tot.withinss
}
plot(kmCrit, type="o", xlab = "stevilo skupin (k)", ylab = "vrednost Wardove kriterijske funkcije")

# povecaj stevilo iteracij (iter.max), v primeru, da algortiem kmeans ne skonvergira
# iter.max = maksimlano stevilo iteracij
# nstart = stevilo ponovitev algoritma (da se izognemo lokalnemum optimumu)
# B = stevilo bootstrap vzorcev
# poglej ?clusGap !
gskmn <- clusGap(SviriData, FUN = kmeans, iter.max = 100, nstart = 100, K.max = 8, B = 100, d.power = 2)
plot(gskmn, main = "GAP statistika za razlicno\nstevilo skupin", xlab = "stevilo skupin")

# nastavimo seme, da bomo dobili vsi enake rezultate
set.seed(123)
km3 <- kmeans(x = SviriData, centers = 3, nstart = 1000) 

par(mfrow=c(1,2), mar = c(10, 5, 1, 1))
plotMeans(viriData, by= km3$cluster, ylim = c(1, 5), ylab = "povprecja\nnestandardiziranih spremenljivk", plotLegend = FALSE, xlab = "")
plotMeans(SviriData, by=km3$cluster, ylim = c(-2, 2), ylab = "povprecja\nstandardiziranih spremenljivk", plotLegend = FALSE, xlab = "")

# primer izracuna silhuete
library(cluster)
sis <- NULL
for (i in 2:10){
  cluster <- kmeans(x = SviriData, centers = i, nstart = 100, iter.max = 20)$cluster
  si <- silhouette(cluster, daisy(SviriData))
  sis[i] <- mean(si[,3])
}
plot(sis, type = "b", xlab = "stevilo skupin", ylab = "povprecna silhueta")
#######################################################################################
#                            RAZVRSCANJE NA PODLAGI MODELOV
#######################################################################################
# Metoda poredpostavlja multivariatno normalno porazdelitev. 
# V primeru da predpostavka drzi, se v vecini simulacij metoda izkaze kot optimalna.
# https://journal.r-project.org/archive/2016/RJ-2016-021/index.html

# naredimo razvrstitev na originalnih podatkih
# funkcija sama izbere najprimernejsi model
# G pomeni stevilo skupin za razvrscaje (od-do)
mc <- Mclust(viriData, G=1:10)
# pogledamo vrednosti BIC (Bias information critery)
# zelimo cim vecje vrednosti
plot(mc, what = "BIC")
# funkcija summary izpise ime izbranega modela in velikosti skupin
# model je izbran na podlagi kriterija BIC 
# EEV -> elipsoidne skupine, ki so enako velike (v smislu prostora, ki ga zajemajo v
# koordinatnem sistemu) in enako usmerjene
summary(mc)

# priorControl za dolocitev prir probabilities
# Rezultira v bolj stabilnih ocenah, a lahko povzroci pristranskost.
mcP <- Mclust(viriData, G=1:10, prior = priorControl())
summary(mcP)
plot(mcP, what = "BIC")

# resitve lahko pogledamo tudi graficno
# (ni potrebno vkljuciti v domaco nalogo)
plot(mcP, what="classification", asp = 1) # tocke so pobarvane glede na pripadnost k skupini
plot(mcP, what="uncertainty", asp = 1) # vecje tocke pomenijo bolj negotovo razvrstitev

# STANDARDIZIRANI PODATKI
# Med rezultati, kjer analiziramo standardizirane in nestandardizirane podatke, 
# po teoriji pri modelih, kjer porazdelitev (distribution v clanku spodaj) ni okrogla (spherical), 
# (se pravi pri oznaki modela na sredini ni "I"), ne bi smelo biti razlik. 
mcStdP <- Mclust(SviriData, G=1:10, prior = priorControl())
plot(mcStdP, what="BIC")
summary(mcStdP)

par(mfrow=c(1,3))
plot(mc, what="BIC", legendArgs = list(x = "bottomright"))
title(main="no prior, no std")
plot(mcP, what="BIC", legendArgs = list(x = "topleft"))
title(main="prior, no std")
plot(mcStdP, what="BIC", legendArgs = list(x = "topleft"))
title(main="prior, std")

# OMEJITEV NA SPECIFICNE MODELE
# Vcasih je bolje omejiti nabor modelov, recimo da samo tiste, ki imajo 
# enako velikost, morda celo na okrogle (kar je potem skoraj enakovredno K-means ali ward).
# EII je model, ki ga isce k-means. Poleg tega je tudi model, ki isce okrogle, 
# enako velike skupine (kar se tice volumna, ne stevila enot). 
# Ce volumna ne fisiramo, lahko dobimo skupine, kjer je ena znotraj druge. 
# Ce drugi dve komponenti ne nastavimo vsaj na EE (obe), potem lahko dobimo skupine, ki se krizajo. 
# Oboje je lahko vcasih nezazeljeno. Oboje sicer preprecimo tudi z modelom EEE. 
mcSEL <- Mclust(SviriData, G=2:7, prior = priorControl(), modelNames = c("EII", "EEE"))
plot(mcSEL, what="BIC", legendArgs = list(x = "bottomright"))
mcEEE3 <- Mclust(jitter(SviriData), G = 3, prior = priorControl(), modelNames = "EEE")
mcEEE5 <- Mclust(jitter(SviriData), G = 5, prior = priorControl(), modelNames = "EEE")

# narisemo povprecja odgovorov po skupinah 
par(mfrow=c(2,2), mar = c(10, 5, 1, 1))
plotMeans(viriData, by= mcEEE3$classification, ylim = c(1, 5), main="", ylab = "povprecja\nnestandardiziranih spremenljivk", plotLegend = FALSE) 
plotMeans(SviriData, by=mcEEE3$classification, ylim = c(-2, 2), main="", ylab = "povprecja\nstandardiziranih spremenljivk", plotLegend = FALSE) 
plotMeans(viriData, by= mcEEE5$classification, ylim = c(1, 5), main="", ylab = "povprecja\nnestandardiziranih spremenljivk", plotLegend = FALSE) 
plotMeans(SviriData, by=mcEEE5$classification, ylim = c(-2, 2), main="", ylab = "povprecja\nstandardiziranih spremenljivk", plotLegend = FALSE) 

# pogledamo stevilo enot po skupinah
table(mcEEE3$classification)
table(mcEEE5$classification)
#######################################################################################
#                            PRIMERJAVA RAZVRSTITEV
#######################################################################################
# iz vsake metode (hierarhicne, nehierahicne, na podlagi modelov) izberemo najboljso razvrstitev
# in ponovno pogledamo povprecja po skupinah ter jih primerjamo
par(mfrow = c(1, 3), mar = c(10, 5, 1, 1))
plotMeans(SviriData, by=km3$cluster, ylim = c(-2, 2), ylab = "povprecja\nstandariziranih spremenljivk", plotLegend = FALSE, main = "k-means", xlab = "") 
plotMeans(SviriData, by=wardK3, ylim = c(-2, 2), ylab = "povprecja\nstandariziranih spremenljivk", plotLegend = FALSE, main = "Ward", xlab = "") 
plotMeans(SviriData, by=mcEEE3$classification, ylim = c(-2, 2), ylab = "povprecja\nstandariziranih spremenljivk", plotLegend = FALSE, main = "na podlagi modelov", xlab = "") 

# kako podobni sta si razvrstitvi
crand(table(wardK3, km3$cluster))
crand(table(wardK3, mcEEE3$classification))
crand(table(km3$cluster, mcEEE3$classification))

# kontingencna tabela
# razmislite o smiselnosti kontingencne tabele (vrstni red vrstic in stolpcev)
# diag = delez enot na diagonali
# kappa = normaliziran delez enot na diagonali
kont.tabela <- table(km3$cluster, wardK3)[, c(1,3,2)]
kont.tabela
classAgreement(kont.tabela)

# katera razvrstitev je boljsa glede na WKF?
wardKF(X = SviriData, clu = wardK3)
wardKF(X = SviriData, clu = km3$cluster)
wardKF(X = SviriData, clu = mcEEE3$classification) 
#######################################################################################
#                            PREDSTAVITEV REZULTATOV -- INTERPRETACIJA
#######################################################################################
par(mfrow = c(1, 2))
plotMeans(viriData, by=km3$cluster, ylim = c(1, 5), ylab = "povprecja\nnestandariziranih spremenljivk", plotLegend = FALSE, main = "k-means", xlab = "") 
plotMeans(SviriData, by=km3$cluster, ylim = c(-2, 2), ylab = "povprecja\nstandariziranih spremenljivk", plotLegend = FALSE, main = "k-means", xlab = "") 

# nekako poimenujemo skupine in pripadnost k skupini shranimo v podatke
viriData$raz <- raz <- factor(km3$cluster, labels=c("nadpovprecno za vse vire", "nadpovprecno za obnovljive vire", "podpovprecno za obnovljive vire"))
viriData$raz <- factor(viriData$raz, labels = levels(raz)) 

# dodamo legendo
par(mfrow = c(1, 2))
plotMeans(viriData[, viri], by=raz, ylim = c(1, 6), ylab = "povprecja\nnestandariziranih spremenljivk", plotLegend = TRUE, main = "k-means", xlab = "") 
plotMeans(SviriData[, viri], by=raz, ylim = c(-2, 2), ylab = "povprecja\nstandariziranih spremenljivk", plotLegend = TRUE, main = "k-means", xlab = "") 

# velikost skupin
table(raz)

# Narisemo enote v 3D prostoru (likartovih lestvic)
# Ali v 2D prostoru Likertovih lestvic (ce imamo 2 Lik. lestvici)
# Spremeni "plot" v "pairs
par(mfrow = c(1, 1))
lik <- cbind(rowMeans(viriData[, tradicionalniViri]), 
             rowMeans(viriData[, alternativniViri]))
likS <- jitter(lik, amount = 0.1)
colnames(likS) <- c("tradicionalni viri", "alternativni viri")

plot(likS, 
      pch = 16, cex = 0.5,
      col = viriData$raz,
      ylim = c(1, 5), xlim = c(1,5))
par(xpd=TRUE)
legend("bottomright", 
       legend = levels(viriData$raz), 
       col = 1:3, 
       pch = 16,
       xpd = T)

# vpliv dodatnih spremenljivk na razvrstitev v skupino
# preverimo graficno
# opravimo statisticni test
# preverimo moc povezanosti, kjer je smiselno
barplot(prop.table(table(raz, podatki[com, "spol"]), 2), 
        beside = TRUE,
        legend = TRUE,
        ylim = c(0, 1),  
        names.arg = levels(podatki$spol),
        col = 1:3)
chisq.test(table(podatki[com, "spol"], raz))
cramer.v(table(podatki[com, "spol"], raz))

izobrazbaTabela <- table(raz, podatki[com, "izobrazba"])[,-14]
barplot(prop.table(izobrazbaTabela, 2), 
        beside = TRUE,
        legend = TRUE,
        ylim = c(0, 1),  
        names.arg = colnames(izobrazbaTabela),
        col = 1:3, las = 2)
kruskal.test(x = podatki[com, "izobrazba"], g = raz)
cramer.v(izobrazbaTabela)

barplot(prop.table(table(raz, podatki[com, "sektor"]), 2), 
        beside = TRUE,
        legend = TRUE,
        ylim = c(0, 1),  
        names.arg = levels(podatki$sektor),
        col = 1:3, las = 2)
# ce so frekvence v kaksnih celicah zelo majhne
# lahko dobite opozorilo o nevljavnih p-vrednostih
# mozna resitev je uporaba bootstrap vzorcev za oceno p-vrednosti
chisq.test(table(podatki[com, "sektor"], raz)) # .. ali ...
chisq.test(table(podatki[com, "sektor"], raz), simulate.p.value = TRUE, B = 10000) 
cramer.v(table(podatki[com, "sektor"], raz))

plotmeans(podatki[com, "starost"] ~ raz, legends = levels(raz), 
          ylab = "starost", 
          xlab = "skupina")
oneway.test(starost ~ raz, data=podatki[com, ], var.equal = FALSE) 
###################################################################
#                    THE END
###################################################################

library("lavaan")
library("semTools")
library("semPlot")
library("foreign") 
library("car")
library("multiUS") # preverite, ce uporabljate najnovejso verzijo
# install.packages("multiUS", repos="http://R-Forge.R-project.org")

# Nekaj dodatnega gradiva o uporabi paketka lavaan lahko najdete na spodnjih povezavah.
# http://lavaan.ugent.be/tutorial/index.html
# https://www.jstatsoft.org/article/view/v048i02
# https://stats.idre.ucla.edu/r/seminars/rcfa/

#######################################################################################
#                            PRIPRAVA PODATKOV
#######################################################################################
# uvoz podatkov SPSS
podatkiVseDrzave <- read.spss("../ESS8e02_1.sav",
                              use.value.labels = TRUE,
                              to.data.frame = TRUE,
                              use.missings = TRUE,
                              reencode = TRUE)

# analizirali bomo podatke za Slovenijo in Estonijo
dve.drzavi <- podatkiVseDrzave[podatkiVseDrzave$cntry %in% c("Slovenia", "Estonia"),]
table(dve.drzavi$cntry)
rm(podatkiVseDrzave)

# preimenujemo spremenljivke 
colnames(dve.drzavi)[which(colnames(dve.drzavi) == "gndr")] <- "spol"
colnames(dve.drzavi)[which(colnames(dve.drzavi) == "cntry")] <- "drzava"
colnames(dve.drzavi)[which(colnames(dve.drzavi) == "agea")] <- "starost"
# D24: Koliko vas skrbi zaradi podnebnih sprememb?
colnames(dve.drzavi)[which(colnames(dve.drzavi) == "wrclmch")] <- "klimatske"

# uporabljali bomo "vsebinske" spremenljivke
tradicionalniViri <- c("premog", "plin", "jedrska")
alternativniViri  <- c("biomasa", "sonce", "veter")
viriEnergije <- c(tradicionalniViri, alternativniViri)
viriEnergijeEN <- c("elgcoal", "elgngas", "elgnuc", "elgbio", "elgsun", "elgwind")

# preimenujemo stolpce - nujno je, da sta vrstna reda sprememnljivk v viriEnergijeEN in viriEnergije enaka
colnames(dve.drzavi)[which(colnames(dve.drzavi) %in% viriEnergijeEN)] <- viriEnergije

# izberemo podatke, ki vsebujejo samo potrebne spremenljivke
data_all <- dve.drzavi[, c(viriEnergije, "spol", "starost", "drzava", "klimatske")]
dataSLOEST <- data_all[complete.cases(data_all),]

# vrednosti bomo obravnavali kot stevilske (intervalne)
# zato jih rekoridamo in obrnemo lestvico
# (tako da bo vecja vrednost pomenila vec, manjsa pa manj)
for (i in 1:length(viriEnergije)) {
  # rekodiranje
  dataSLOEST[, viriEnergije[i]] <- Recode(dataSLOEST[, viriEnergije[i]], "
                                                       'None at all' = 1;
                                                       'A small amount' = 2;
                                                       'A medium amount' = 3;
                                                       'A large amount' = 4;
                                                       'A very large amount' = 5;
                                                       'I have not heard of this energy source before' = NA
                                                       ")
  # pretvorba iz ordinalne v numericno spremenljivko
  dataSLOEST[, viriEnergije[i]] <- as.numeric(as.character(dataSLOEST[, viriEnergije[i]]))
}

# rekodiramo spol
dataSLOEST$spol <- car::recode(dataSLOEST$spol, "'Male' = 1; 'Female' = 0")
dataSLOEST$spol <- as.numeric(as.character(dataSLOEST$spol))
table(dataSLOEST$spol)

# rekodiramo podnebne spremembe
table(dataSLOEST$klimatske)
dataSLOEST$klimatske <- car::recode(dataSLOEST$klimatske, "'Not at all worried'=1;   'Not very worried'=2;   'Somewhat worried'=3; 'Very worried'=4;  'Extremely worried'=5")
dataSLOEST$klimatske <- as.numeric(dataSLOEST$klimatske)

# spremenljivko starost nastavimo kot numericno
dataSLOEST$starost <- as.numeric(dataSLOEST$starost)

# izberemo podatke samo za Slovenijo
dataSLO <- dataSLOEST[dataSLOEST$drzava == "Slovenia",]
# options(scipen=999)
#######################################################################################
#                            VAJA 1: POTRJEVALNA FAKTORSKA ANALIZA
#######################################################################################
# za definiranje faktorjev uporabljamo oznako =~ ki pomeni "se izraza skozi"
# na levo stran napisemo ime faktorja, na desno pa imena manifestnih spremenljivk
modelCfa <- "
# latentne spremenljivke
tradicionalniViri =~ premog + plin + jedrska 
alternativniViri  =~ biomasa + sonce + veter 
"

# da bi zagotovili identifikabilnost modela, moramo
#---a) nastaviti eno fiksno utez za vsak faktor (privzeto)
#---b) standardizirati variance odklonov latentnih spremenljivk (std.lv = FALSE)
# dodatni paramteri so:
#---a) mimic = "Mplus"; za zeljeno obliko izpisa
#---b) orthogonal; FALSE za nepravokotne faktorje, TRUE za pravokotne
#---c) estimator; pogosto DWLS, ko imamo ordinalne spremenljivke
fitCfa <- cfa(modelCfa, data = dataSLO, orthogonal = FALSE, estimator = "DWLS") 

# pogledamo rezultate modelov
#---a) fit.measures; kako dobro se model prilega
#---b) standardized; vrne standardizirane vrednosti koeficientov
summary(fitCfa, fit.measures = TRUE, standardized = TRUE)
# Std.lv = standardizirane vrednosti latentnih spremenljivk
# Std.all = standardizirane vrednosti vseh spremenljivk

# mere prileganja lahko izpisemo tudi z uporabo funkcije fitMeasures
fitMeasures(fitCfa)[c("pvalue", "rmsea", "cfi", "tli")]

# narisemo resitev
# what; kaj narisati, glej ?semPaths
# whatLabels; kaj napisati na povezave, obicajno "est" ali "std"
# edge.label.cex; velikost napisov
semPaths(fitCfa, what = 'path', whatLabels = 'est', edge.label.cex = 1)
semPaths(fitCfa, what = 'path', whatLabels = 'std', edge.label.cex = 1)

# ce se model slabo prilega podatkom, potem lahko razmislimo o dodajanju nekaterih sprostitev
# razmislimo o tistih sprostitvah, pri katerih je vrednost mi (modification index) najvecja
# mi je pricakovano zmanjsanje statistike hi2, ce sprostimo izbran parameter
# EPC je pricakovana spreemba parametra
# zadnji trije stolpci so razlicne standardizirane vrednosti EPC
# (sepc.nox = standardizirane vrednosti vseh, razen eksogenih spremenljivk)
modInd <- modificationindices(fitCfa)
subset(modInd, mi > 10)

modelCfa2 <- "
# latentne spremenljivke
# spremenljivka plin ima nenicelne utezi na obeh faktorjih
tradicionalniViri =~ premog + plin + jedrska
alternativniViri  =~ biomasa + sonce + veter + plin
"

# naredimo nov model in pogledamo mi
fitCfa2 <- cfa(modelCfa2, data = dataSLO, orthogonal = FALSE, estimator = "DWLS")
fitmeasures(fitCfa2, fit.measures = c("srmr","rmsea","tli","cfi"))

summary(fitCfa2, fit.measures = TRUE, standardized = TRUE)
modInd <- modificationindices(fitCfa2)
subset(modInd, mi > 10)

semPaths(fitCfa2, what = 'path', whatLabels = 'est', edge.label.cex = 1)
semPaths(fitCfa2, what = 'path', whatLabels = 'std', edge.label.cex = 1)

# preverimo, ali se bolj kompleksen model bolje prilega podatkom
# Ho: modela se enako dobro prilegata podatkom
anova(fitCfa2, fitCfa)

# pogledamo moznost za omejitev varianc latentnih spremenljvk
fitCfa.var <- cfa(modelCfa2, data = dataSLO, estimator = "DWLS", std.lv = TRUE)
summary(fitCfa.var, fit.measures = TRUE, standardized = TRUE)

# pogledamo moznost obravnave endogenih spremenljivk kot 
# spremenljivk ordinalne merske lestvice
# eksogene spremenljivke obravnavamo kot pri navadni linearni regresiji
fitCfa2Ord <- cfa(modelCfa2, data = dataSLO, orthogonal = FALSE, estimator = "DWLS", ordered = viriEnergije) 
fitmeasures(fitCfa2Ord, fit.measures = c("srmr","rmsea","tli","cfi"))
#######################################################################################
#                            VAJA 2: MIMIC MODEL
#######################################################################################
modelMimic <- "
# latentne spremenljivke
alternativniViri  =~ biomasa + sonce + veter + plin
# regresija
alternativniViri ~ spol + starost + klimatske 
"

fitMimic <- sem(modelMimic, data = dataSLO, estimator = "DWLS", ordered = viriEnergije)
fitmeasures(fitMimic, fit.measures = c("srmr","rmsea","tli","cfi"))
modInd <- modificationindices(fitMimic)
subset(modInd, mi > 10)
summary(fitMimic, fit.measures = TRUE, standardized = TRUE, rsquare = TRUE)
# intercepts; ali naj izpise tudi presecisca?
semPaths(fitMimic, what = 'path', whatLabels = 'est', intercepts = FALSE, edge.label.cex = 1.2)
semPaths(fitMimic, what = 'path', whatLabels = 'std', intercepts = FALSE, edge.label.cex = 1.2)
#######################################################################################
#                            VAJA 3: POLNI SEM
#######################################################################################
modelFullSem <- "
# latentne spremenljivke
tradicionalniViri =~ premog + plin + jedrska 
alternativniViri  =~ biomasa + sonce + veter + plin
# regresija
tradicionalniViri ~ starost + spol + klimatske
alternativniViri ~ starost + spol + klimatske
klimatske ~ spol + starost 
"

fitFullSem <- sem(modelFullSem, data = dataSLO, estimator = "DWLS", ordered = viriEnergije) 
fitmeasures(fitFullSem,fit.measures = c("srmr","rmsea","tli","cfi"))
modInd <- modificationindices(fitFullSem)
subset(modInd, mi > 10)

summary(fitFullSem, fit.measures = TRUE, standardized = TRUE, rsquare = TRUE)
semPaths(fitFullSem, what = 'path', whatLabels = 'std', intercepts = FALSE)

# := lahko beremo kot "definira" ali "je enako"
modelFullSemPosr <- "
# latentne spremenljivke
tradicionalniViri =~ premog + plin + jedrska
alternativniViri  =~ biomasa + sonce + veter + plin
# regresija
tradicionalniViri ~ starost + c*spol + b*klimatske
alternativniViri ~ starost + spol + klimatske
klimatske ~ a*spol + starost 
# posredni in skupni ucinki
posredni := a*b
skupni := c + posredni
"

fitFullSemPosr <- sem(modelFullSemPosr, data = dataSLO, estimator = "DWLS", ordered = viriEnergije) 
fitmeasures(fitFullSemPosr, fit.measures = c("srmr","rmsea","tli","cfi"))
modInd <- modificationindices(fitFullSemPosr)
subset(modInd, mi > 10)

summary(fitFullSemPosr, fit.measures = TRUE, standardized = TRUE, rsquare = TRUE)
semPaths(fitFullSemPosr, what = 'path', whatLabels = 'std', intercepts = FALSE)
#######################################################################################
#                            VAJA 4: MERSKA ENAKOVREDNOST
#######################################################################################
dve_skupini <- cfa(modelCfa2, 
                          data = dataSLOEST, 
                          orthogonal = FALSE, 
                          estimator = "DWLS", 
                          std.lv = TRUE, 
                          group = "drzava") 
par(mfrow = c(1, 2)); semPaths(dve_skupini, what = 'path', whatLabels = 'est', intercepts = FALSE, edge.label.cex = 1.2)

# funkcija measurmentInvariance preverja prileganje modelov
# z razlicnimi omejitvami vrednosti parametrov 
# (tj. razlicnimi vrstami enakovrednosti)
# dolociti moramo spremenljivko, ki doloca skupine
measurementInvariance(model=modelCfa2, 
                      data = dataSLOEST, 
                      group = "drzava",
                      estimator = "DWLS",
                      orthogonal = FALSE, 
                      fit.measures = c("rmsea","cfi","tli","srmr"))

# Delno metricno enakovrednost lahko dosezemo tako, da fiksiramo
# vrednosti parametrov za vsaj dve manifestni spremenljivki
# pri vsaki latentni.
# V nasem primeru je to malo na silo, ker so si vrednosti
# zelo razlicne in ker imamo zelo malo manifestnih spremenljivk.
# Kazemo zgolj za ilustracijo, kako se fiksira vrednosti.
delnaMetricnaEnakovrednost <- "
# latentne spremenljivke
tradicionalniViri =~ c(z, z)*premog + c(w, w)*plin + jedrska
alternativniViri  =~ c(x, x)*biomasa + c(y, y)*sonce + veter + plin
"

delniMetricniModel <- cfa(delnaMetricnaEnakovrednost, 
                          data = dataSLOEST, 
                          orthogonal = FALSE, 
                          estimator = "DWLS", 
                          std.lv = TRUE, 
                          group = "drzava") 
par(mfrow = c(1, 2)); semPaths(delniMetricniModel, what = 'path', whatLabels = 'est', intercepts = FALSE, edge.label.cex = 1.2)

#######################################################################################
#                            VAJA 5: POLNI SEM MODEL ZA VEC SKUPIN
#######################################################################################
# Predpostavljamo delno mestricno enakovrednost.
modelFullSemPosrVecSkupin <- "
# latentne spremenljivke
tradicionalniViri =~ c(z, z)*premog + c(w, w)*plin + jedrska
alternativniViri  =~ c(x, x)*biomasa + c(y, y)*sonce + veter + plin
# regresija
tradicionalniViri ~ starost + c*spol + b*klimatske
alternativniViri ~ starost + spol + klimatske
klimatske ~ a*spol + starost 
# posredni in skupni ucinki
posredni := a*b
skupni := c + (a*b)
"

# Nekatere ocenene variance so negativne, kar je posledica zelo slabo
# dolocenega modela. Takega modela formalno ne bi interpretirali.
modelFullSemVecSkupin <- sem(modelFullSemPosrVecSkupin, data = dataSLOEST, estimator = "DWLS", group = "drzava") 
fitmeasures(modelFullSemVecSkupin, fit.measures = c("srmr","rmsea","tli","cfi"))

summary(modelFullSemVecSkupin, fit.measures = TRUE, standardized = TRUE, rsquare = TRUE)

par(mfrow = c(1, 2)); semPaths(modelFullSemVecSkupin, what = "path", whatLabels = "est", intercepts = FALSE, edge.label.cex = 1) 
library(MASS)
n<-200
X1<-mvrnorm(n = n, mu = c(0,0), Sigma = diag(2))
X2<-mvrnorm(n = n, mu = c(2,2), Sigma = diag(2))

X<-rbind(X1,X2)
clu<-rep(1:2, each=n)

plot(X, col=clu)

dV<-Inf
V<-X[sample(nrow(X),2),]
V<-cbind(c(0,-2),c(-1,0))
plot(X, col=clu)
points(V,pch=19, cex=2, col=1:2)
i<-0

while(dV>10^(-15)){
  d1<- rowSums((X-V[rep(1,nrow(X)),])^2)
  d2<- rowSums((X-V[rep(2,nrow(X)),])^2)
  iClu<-apply(cbind(d1,d2),1,which.min)
  # plot(X, col=iClu)
  iV<-aggregate(x = X,by=list(iClu),FUN=mean)[,-1]
  dV<-sum((V-iV)^2)
  V<-iV
  i<-i+1
  print(c(dV, i))
  points(V,pch=as.character(i), cex=2, col=1:2)
}
i
V
table(iClu)
table(clu,iClu)





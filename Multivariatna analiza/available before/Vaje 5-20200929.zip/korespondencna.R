library("GDAtools")
library("foreign")
library("FactoMineR")
library("multiUS")

add_modified_rates <- function(mca){
  Q <- length(mca$call$quali)
  lambda_pseudo <- ((Q/(Q-1)) * (mca$eig[,"eigenvalue"] - (1/Q)))**2
  pos_lambda <- mca$eig[,"eigenvalue"] > (1/Q)
  S <- sum(lambda_pseudo[pos_lambda])
  modified_rate <- lambda_pseudo*pos_lambda/S*100
  cum_modified_rate <- cumsum(modified_rate)
  return(data.frame(mca.rez$eig, "modified_rate" = modified_rate, "cum_modified_rate" = cum_modified_rate))
}

# POLITICNE STRANKE -------------------------------------------------------

# uvoz podatkov SPSS
load("../ESS_SLO_rekodirane", verbose = TRUE)

# uporabljali bomo samo enote, ki imajo vrednosti pri vseh spremenljivkah
# izbrali smo spremenljviki politicna stranka (koga je volil) in
# spremenljivko sektor
com <- complete.cases(podatki[, c("prtvtesi", "sektor")])
data <- podatki[com, c("prtvtesi", "sektor")]

sort(table(data$prtvtesi))

# korespondencna analiza
# kontingencna tabela
kont <- table(data)
dim(kont)
# izvedemo korespondencno analizo
mca.rez <- CA(kont)
mca.rez$eig


# PRIMER TO SEM JAZ -------------------------------------------------------

# nalozimo podatke
tsj <- read.table("tsj_vaje.txt", header = TRUE)
# pogledamo zapis podatkov
head(tsj)
# pogledamo posamezne porazdelitve
barplot(table(tsj$st_znakov_rec))
barplot(table(tsj$spol))
barplot(table(tsj$starost))
par(oma = c(10, 0, 0, 0))
barplot(sort(table(tsj$krovna_kat), decreasing = T), las = 2)

# naredimo Burtovo tabelo
(burtova <- burt(data = tsj))
plotMat(burtova)
# izvedemo korespondencno analizo
par(mfrow = c(2, 2))

# slika, ki jo vrne spodnji ukaz prikazuje korelacijo med 
# spremenljivkami ter dimenzijmai MCA
mca.rez <- MCA(tsj, ncp = 16, method = "Indicator")
# pogledamo, koliko pojasnimo s posamezno dimenzijo in se odlocimo za primerno stevilo dimenzij

# izpisemo tabelo
# eigenvalue - lastne vrednosti
# percentage of variance - delez pojasnjene variabilnosti
# cumulative percentage of variance - kumulativen delez pojasnjene variabilnosti
# modified_rate - delez pojasnjene variabilnosti, po tem, ko upostevamo 
# samo tiste dimenzije, ki katerih inercije so visje od 1/st_spremenljivk inercije
round(add_modified_rates(mca.rez), 2)

# narisemo rezultat; invisible = "ind" pomeni "naredi individualne vrednosti nevidne"
plot(mca.rez, invisible = "ind")

# dodatno branje
# http://www.sthda.com/english/articles/31-principal-component-methods-in-r-practical-guide/114-mca-multiple-correspondence-analysis-in-r-essentials/

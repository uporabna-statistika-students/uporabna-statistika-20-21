library(car)
library(blockmodeling)
library(multiUS)

# PRIPRAVA PODATKOV -------------------------------------------------------

# uvoz podatkov SPSS
load("../ESS_SLO_rekodirane", verbose = TRUE)

tradicionalniViri <- c("premog", "plin", "voda", "jedrska")
alternativniViri  <- c("biomasa", "sonce", "veter")

viriEnergije <- c(tradicionalniViri, alternativniViri)

# uporabljali bomo samo enote, ki imajo vrednosti pri vseh spremenljivkah
com <- complete.cases(podatki[, c(viriEnergije, "sektor")])
viriData <- podatki[com, c(viriEnergije, "sektor")]

# PREDPOSTAVKE DISKRIMINANTNE ANALIZE -------------------------------------

# izracunamo frekvence po kategorijah
# (vsaj dve enoti morata biti v vsaki skupini)
# p < (n-1) (p je stevilo spremenljivk, n je stevilo enot)
(status_t <- table(as.character(viriData$sektor)))
# izracunamo deleze po kategorijah (+ za utemeljitev predpostavljene verjetnosti na populaciji)
prop.table(status_t)

# preverimo multikolinearnost
plotMat(cor(viriData[, viriEnergije]), main = "")

# nobena spremenljivka ne sme biti linarna kombinacija ostalih spremenljivk

# variancno-kovariancna matrika je v vsaki populacijski skupini enaka
# ce je predpostavka krsena, lahko uporabimo kvadratno diskriminantno analizo
# pogledamo tabele
par(mfrow = c(2, 2))
matrike <- by(data = viriData[, viriEnergije], INDICES = viriData$sektor, FUN = cov)
for (i in names(matrike)){
  plotMat(matrike[[i]], main = i, mar = rep(3, 4), title.line=0, print.x.axis.val = FALSE)
} 

# Box M-test 
# Ho: Vse variancno-kovariancne matrike so enake.
# (test ni robusten na odstopanja od normalnosti)
# ce je ta predpostavka krsena, bo vecja verjetnost, da bodo 
# enote razvrscene v vecjo (bolj variabilno) skupino
BoxMTest(X = viriData[, viriEnergije], 
         cl = as.factor(viriData$sektor), 
         alpha = 0.05, 
         test = FALSE)

# ce so razlike v povprecjih majhne, lahko pricakujemo, da bomo
# z diskriminatnimi funkcijami slabo locevali med skupinami
# pogledamo povprecja po skupinah glede na odvisno spremenljivko
dev.off()
plotMeans(x = viriData[, viriEnergije], 
          by = viriData[, "sektor"], 
          ylim = c(1, 5), 
          ylab = "Povprecja", 
          xleg = "bottomright")

# MANOVA
# Ho: vsa povprecja intervalnh spremenljivk so enaka med skupinami
summary(manova(as.matrix(viriData[, viriEnergije]) ~ viriData$sektor))

# preverimo, med katerimi kategorijami obstajajo razlike v povprecjih
for (i in 1:length(viriEnergije)) {
  a <- summary(aov(viriData[, viriEnergije[i]] ~ viriData$sektor))
  cat(viriEnergije[i], "\t F(", a[[1]][1,1], "; ", a[[1]][2,1], ") = ", round(a[[1]][1,4], 3), " \t p = ", round(a[[1]][1,5], 3), "\n", sep = "")
}

# POMEMBNOST IN STEVILO DISKRIMINANTNIH FUNKCIJ ---------------------------

# izvedemo linearno diskriminantno analizo na standardiziranih podatkih
# ker nismo nastavili parametra "prior", funkcija oceni verjetnosti po skupinah iz podatkov
# te vrejtnosti se uporabijo pri klasifikaciji
# CV = cross validation (jackknife)
LDARes <- ldaPlus(x = viriData[, viriEnergije],
                   grouping = viriData$sektor,
                   pred = TRUE,
                   CV = TRUE)

# standardizirane koeficiente dobimo kot
# lahko tudi kot LDARes$standCoefWithin
LDARes$standCoefTotal
# nestandardizirani koeficienti so uporabni, ko zelimo 
# delovanje metode preveriti na drugih podatkih

# pogledamo vrednosti kanonicnih korelacij
# kako mocno sta povezana sklopa spremenljivk
# (ce gledamo linearni kobinaciji spremenljivk sklopov s takimi
# vrednostmi regresijskih utezi, da je korelacija maksimalna)
# % - ita DF pojasni X% razlik med povprecji
# Cor - korelacija med ito DF in dummy spremenljvko je X
# Sq. Cor. - ita DF pojasni X% variabilnosti v spremenljivkah, ki predstavljajo skupine
round(LDARes$eigModel, 3)

# preverimo statisticno znacilnost diskriminatnih funkcij
# Ho: povprecja diskriminantnih funkcij po skupinah so enaka
options(scipen = 999)
round(LDARes$sigTest, 3)
#######################################################################################
#                            POMEN DISKRIMINANTNIH FUNKCIJ
#######################################################################################
# najprej nas zanima, med katerimi skupinami locuje posamezna diskriminantna funkcija
round(LDARes$centroids, 3)
# 1DF:   javni sektor vs. ostale kategorije
# 2DF:   ostalo in javni sektor vs. podjetja (predvsem podjetje v javni lasti)

# sedaj nas zanimajo spremenljivke, ki imajo najvecji vpliv
# na vrednosti diskriminantne funckcije (spremenljivke, ki najbolj locujejo med skupinami)
# ker je bila metoda izvedena na standardzitranih podatkih,
# so to spodaj standaardizirane vrednosti diskriminantne funkcije
(nest.coef <- LDARes$scaling)
plotMat(nest.coef, mar = c(1, 5, 5, 1), main = "")

# za interpretacijo lahko uporabimo tudi korelacije med
# vrednostmi diskriminatne funkcije in pojasnjevalno spremenljivko
korelacije <- cor(viriData[, viriEnergije], LDARes$pred$x)
plotMat(korelacije, mar = c(1, 5, 5, 1), main = "")

# pogosto se gledajo "pooled" corelacije zntoraj skupin
korelacije <- LDARes$corr
plotMat(korelacije, mar = c(1, 5, 5, 1), main = "")

# KVALITETA OCENJENEGA MODELA ---------------------------------------------

# pogledamo, kako so organizirani dobljeni rezultati
# class = razvrstitev
# posterior. = Fisherjeve klasifikacijske funkcije 
# x.LD - vrednosti diskriminantne funkcije
as.data.frame(LDARes$pred)[1:10,]

# pogledamo, klasifikacijsko tabelo 
# Enoto uvrstimo v skupino, katere centorid  v prostoru
# diskriminantnih spremenljivk ji je najbli�je.
# (frekvence in delezi in delez pravilno razvrscenih) na vse podatkih
LDARes$class

# pogledamo, klasifikacijsko tabelo 
# (frekvence in delezi in delez pravilno razvrscenih) z uporabo CV
LDARes$classCV

# za boljso oceno, kako dober je model, je morda dobro pogledati se enkrat 
# prior in dva izracuna na podlagi le-teh:
LDARes$prior
# delez enot, ki bi jih razvrstili pravilno, ce bi vse uvrstili v najveco skupino
max(LDARes$prior)   
# delez enot, ki bi jih razvrstili pravilno, �e bi enote razvrscali povsem slucajno
sum(LDARes$prior^2) 

# sedaj predpostavimo, da so na populaciji vse skupine enako velike
# Ali je to v nasem primeru smiselno glede na vedenje o populacijskih vrednostih?
# Kaksne spremembe pricakujemo? Kaksno bo splosno izboljsanje? Kaj pa po skupinah?
LDAResEqPrior <- update(LDARes,  prior = rep(1/4, times = 4))
# pogledamo rezultate
LDAResEqPrior$class
LDAResEqPrior$classCV

# primerjamo modela
par(mfrow = c(1, 2))
plotMat(LDARes$classCV$perTab[,1:4], main = "")
plotMat(LDAResEqPrior$classCV$perTab[,1:4], main = "")

# razlicne velikosti skupin predpostavimo pri izracunu diskriminantne funkcije
# pri klasifikaciji pa prdpostavimo enake velikosti skupin
LDAResPriorZaIzracun <- ldaPlus(x = viriData[, viriEnergije],
                                 grouping = viriData$sektor,
                                 # spodnji argument, ce je FALSE, potem se prior verjetnosti
                                 # NE uporabi pri ocenjevanju parametrov
                                 # (namesto tega se uporabi verjetnosti na podlagi vzorca)
                                 usePriorBetweenGroups = FALSE,
                                 prior = rep(1/4, times = 4),
                                 pred = TRUE,
                                 CV = TRUE)

# narisemo rezultate in jih primerjamo (koeficiente in klasifikacijske tabele)
par(mfrow = c(2, 3))                              # R = razlicno, E = enako
plotMat(LDARes$scaling, main = "")                # R oceno + R za razvrscanje (vsebovano v oceni)
plotMat(LDAResEqPrior$scaling, main = "")         # E oceno + E za razvrscanje
plotMat(LDAResPriorZaIzracun$scaling, main = "")  # R oceno + E za razvrscanje

plotMat(LDARes$classCV$perTab[, 1:4], main = "")
plotMat(LDAResEqPrior$classCV$perTab[, 1:4], main = "")
plotMat(LDAResPriorZaIzracun$classCV$perTab[, 1:4], main = "")

# ENOTE V PROSTORU DVEH DISKRIMINANTNIH FUNKCIJ ---------------------------

dev.off()
# narisemo navaden razsevni grfikon - tocke so pobarvane glede na pripadnost k skupini
plot(LDARes$pred$x[,1:2],
     col=as.numeric(as.factor(viriData$sektor)),
     cex=0.5,
     pch = 16)
# dodamo legendo
legend(x="bottomright", col=1:5, pch=19, legend = levels(as.factor(viriData$sektor)))
# izracunamo vrednosti centroidov
centroidi <- aggregate(LDARes$pred$x, by = list(viriData$sektor), FUN = mean)
# narisemo centroide
points(centroidi[, 2:3], col = 1:5, cex = 2, pch = 19)
# narisemo osi
abline(h = 0, v = 0)

# sedaj narisemo graf, kjer barve predstavljajo razvrstitev na podlagi modela crke pa dejanske vrednosti
plot(LDARes$pred$x[,1:2], col=LDARes$pred$class,
     pch=c("A", "B", "C", "D")[as.numeric(as.factor(viriData$sektor))],
     cex=0.5)
# dodamo legendi
legend(x="bottomright", col = 1:5, pch=19, levels(LDARes$pred$class))
legend(x="bottomleft", pch=c("A", "B", "C", "D"), levels(LDARes$pred$class))
# izracunamo centroide
# vedno je potrebno pogledati spodnji izpis in
# prilagoditi col v funkciji points, ker se lahko zgodi,
# da bodo nekatere kategorije prazne in bodo zato barve napacne
centroidi <- aggregate(LDARes$pred$x, by = list(LDARes$pred$class), FUN = mean)
points(centroidi[, 2:3], cex = 2, pch = 19, col = c("red", "green", "blue", 5))
# dodamo osi
abline(h = 0, v = 0)

# KVADRATNA DISKRIMINANTNA ANALIZA ----------------------------------------

# izvedemo kvaratno diskriminantno analizo
qdasektor <- qda(x = scale(viriData[, viriEnergije]), grouping = viriData$sektor)
# napovemo pripadnost k skupini (vrednost 'odvisne' spremenljivke)
qdasektor$pred <- predict(qdasektor)
# napovemo pripadnost k skupini (vrednost 'odvisne' spremenljivke) na podlagi CV
qdasektor$predCV <- update(qdasektor, CV = TRUE)
# naredimo klasifickacijsko tabelo
tab <- table(pred = qdasektor$pred$class, obs = viriData$sektor)
prop.table(tab, margin = 2)*100
sum(diag(tab))/sum(tab)*100
# naredimo klasifickacijsko tabelo - CV
tab <- table(pred = qdasektor$predCV$class, obs = viriData$sektor)
prop.table(tab, margin = 2)*100
sum(diag(tab))/sum(tab)*100


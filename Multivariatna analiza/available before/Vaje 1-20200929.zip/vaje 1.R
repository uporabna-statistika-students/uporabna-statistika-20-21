library("car")
library("blockmodeling")
library("foreign")
library("psych")
library("caTools")
library("CCA")
library("gplots")
#install.packages("multiUS", repos="http://R-Forge.R-project.org")
library("multiUS")
#######################################################################################
#                            PRIPRAVA PODATKOV
#######################################################################################
# uvoz podatkov SPSS
podatkiVseDrzave <- read.spss("../ESS8e02_1.sav",
                     use.value.labels = TRUE,
                     to.data.frame = TRUE,
                     use.missings = TRUE,
                     reencode = TRUE)

podatki <- podatkiVseDrzave[podatkiVseDrzave$cntry == "Slovenia",]
rm(podatkiVseDrzave)

# pogledamo, kako izgledajo podatki
head(podatki)
# pogledamo, kaj vsebuje kodirni list
names(attributes(podatki))
attributes(podatki)$names #imena spremenljivk
attributes(podatki)$variable.labels #opis spremenljivk

# izberemo nominalne in/ali ordinalne (kategoricne) spremenljivke
# spol - gndr
# zaposlitveni sektor - tporgwk
# izobrazba - edlvesi
catVarsEN <- c("gndr", "tporgwk", "edlvesi")
catVars <- c("spol", "sektor", "izobrazba")
# pogledamo, kako izgledajo podatki
head(podatki[, catVarsEN])

# izeremo intervalne spremenljivke
# starost - agea
# preimenujemo v bolj clovesko ime
colnames(podatki)[which(colnames(podatki) == "agea")] <- "starost"
podatki$starost <- as.numeric(as.character(podatki$starost))

# izberemo "vsebinske" spremenljivke
viriEnergijeEN <- c(
  "elgcoal", # premog
  "elgngas", # zemeljski plin
  "elghydr", # hidroelektrarne
  "elgnuc",  # jedrska energija
  "elgsun",  # soncna energija
  "elgwind", # veterna energija
  "elgbio"   # biomasa
)

# prevedemo v Slo.
viriEnergije <- c("premog",
                  "plin",
                  "voda",
                  "jedrska",
                  "sonce",
                  "veter",
                  "biomasa")

# preimenujemo stolpce - nujno je, da sta vrstna reda sprememnljivk v 
# viriEnergijeEN in viriEnergije enaka
colnames(podatki)[which(colnames(podatki) %in% viriEnergijeEN)] <- viriEnergije

# pogledamo podatke
head(podatki[, viriEnergije])

# vrednosti bomo obravnavali kot stevilske (intervalne)
# zato jih rekoridamo in obrnemo lestvico
# (tako da bo vecja vrednost pomenila vec, manjsa pa manj)
for (i in 1:length(viriEnergije)) {
  # rekodiranje
  podatki[, viriEnergije[i]] <- Recode(podatki[, viriEnergije[i]], "
                                                       'None at all' = 1;
                                                       'A small amount' = 2;
                                                       'A medium amount' = 3;
                                                       'A large amount' = 4;
                                                       'A very large amount' = 5;
                          'I have not heard of this energy source before' = NA
                                                       ")
  # pretvorba iz ordinalne v numericno spremenljivko
  podatki[, viriEnergije[i]] <- as.numeric(as.character(podatki[, viriEnergije[i]]))
}

#######################################################################################
#                            TOCKA 1-2: PREDSTAVITEV PODATKOV IN REKODIRANJE
#######################################################################################
# spol
table(podatki$gndr)
podatki$spol <- Recode(podatki$gndr, "'Male' = 'moški'; 'Female' = 'ženski'")
table(podatki$spol)

# vrsta podjetja
table(podatki$tporgwk)
podatki$sektor <- car::Recode(
  podatki$tporgwk,
  "
  c('Central or local government', 'Other public sector (such as education and health)') = 'javni sektor';
  'A state owned enterprise' = 'podjetje v javni lasti';
  'A private firm' = 'podjetje v zasebni lasti';
   c('Self employed', 'Other', NA) = 'ostalo';
  "
)
table(podatki$sektor)

# stopnja izobrazbe
table(podatki$edlvesi)

podatki$izobrazba <- podatki$edlvesi
# definiramo kot faktor
podatki$izobrazba <- factor(podatki$izobrazba)
# preverimo vrstni red faktorjev
levels(podatki$izobrazba)
# Other upostevano kot manjkajoco vrednost - 1 respondnet
podatki[podatki$izobrazba %in% "Other", "izobrazba"] <- NA

# uporaba funkcije frekTab (smiselnost kumulativnih % pri nominalni spremenljivki)
freqTab(podatki$spol, dec = 2)[, -c(2, 4)]
freqTab(podatki$sektor, dec = 2)[, -c(2, 4)]
freqTab(podatki$izobrazba, dec = 2)

# graficne predstavitve kategoricnih spremenljivk
# spravimo v for zanko za vse kategoricne spremenljivke
par(mfrow = c(1, 3), mar = c(25,5,5,0))
for (i in 1:length(catVars)){
  barplot(table(podatki[, catVars[i]]),
          ylab = "frekvenca",
          las = 2)
}

# pogledamo se porazdelive stevilskih spremenljivk

# starost
povzetek <- as.data.frame(psych::describe(podatki[, "starost"]))
rownames(povzetek) <- c("starost")
round(povzetek[, c(2, 3, 4, 5, 8, 9, 10, 11, 12)], 2)

povzetek <- as.data.frame(psych::describe(podatki[, viriEnergije]))
round(povzetek[, c(2, 3, 4, 5, 8, 9, 10, 11, 12)], 2)

# histogram za starost
hist(podatki$starost,
     main = "PORAZDELITEV STAROSTI",
     ylab = "Frekvenca",
     xlab = "starost",
     freq = TRUE)

# histogram za vsebinske spremenljivke
par(mfrow = c(2, 4))
for (i in 1:length(viriEnergije)) {
  histNorm(podatki[, viriEnergije[i]],
    breaks = 0:5 + 0.5,
    main = viriEnergije[i],
    xlab = "obseg energije", 
    ylab = "Frekvenca",
    ylim = c(1, 800))
}

#######################################################################################
#                            TOCKA 3: ANALIZA POVEZANOSTI
#######################################################################################
# povezanost spremenljivk o virih energije

# izracunamo korelacije med spremenljivkami
# uporabimo funckcijo s privzetimi vrednostmi
cor(podatki[, viriEnergije])
# upostevamo samo enote, ki imajo vrednosti pri vseh spremenljivkah
# pogledamo, koliksen deleu enot bomo upostevali na tak nacin
mean(complete.cases(podatki[, viriEnergije]))
# izracunamo pearsonov koeficient korelacije
(R.p <- cor(podatki[, viriEnergije], use = "complete.obs", method = "pearson"))

# narisemo korelacije
plot.mat(R.p, main = "Pearsonov koeficient korelacije")

# poskusite spremeniti vrstni red spremenljivk !
vrstni.red <- c(1, 2, 3, 4, 7, 5, 6)
plot.mat(R.p[vrstni.red, vrstni.red], main = "Pearsonov koeficient korelacije")

# izracunamo povprecja strinjanja za prvo spremenljviko o opravicljivosti po spolu
# lahko uporabimo funkcijo describeBy
# (v domaco nalogo vkljucite samo grafe)
describeBy(podatki[, viriEnergije], podatki[, "spol"],  mat = TRUE)[,-c(1, 3, 8, 9)]

# povezanost spremenljivk o upraviciljivosti s kategoricnimi spremenljivkami lahko predstavimo graficno
par(mfrow = c(1, 2), oma = c(5, 2, 1, 1))
plotMeans(x = podatki[, viriEnergije], by = podatki$spol, xlab = "", ylim = c(1, 5), xleg = "topleft")
plotMeans(x = podatki[, viriEnergije], by = podatki$sektor, xlab = "", ylim = c(1, 5), xleg = "bottom")


korelacije <- data.frame(
            cor(podatki[, viriEnergije], as.numeric(podatki[, "izobrazba"]), method = "spearman", use = "com"),
            cor(podatki[, viriEnergije], podatki[, "starost"], method = "pearson", use = "com"))
rownames(korelacije) <- viriEnergije
colnames(korelacije) <- c("izobrazba (Spearman)", "starost (Pearson)")
round(korelacije, 2)
#######################################################################################
#                            TOCKA 4: LIKARTOVE LESTVICE
#######################################################################################
# zdruzimo spremenljivke, ki naj bi merile isto stvar
# navadno to naredimo na podlagi teorije in nato preverimo s faktorsko analizo
# vcasih je dovolj pogledati ze korelacijsko matriko
tradicionalniViri <- c("premog", "plin", "voda", "jedrska")
alternativniViri  <- c("biomasa", "sonce", "veter")

# izracunamo povprecja odgovorov po posameznih sklopih spremenljivk
# temu recemo Likertova lestvica
# (upostevamo razpolozljive vrednosti)
podatki$tradicionalniViri <- rowMeans(x = podatki[, tradicionalniViri], na.rm = TRUE)
podatki$alternativniViri <- rowMeans(x = podatki[, alternativniViri], na.rm = TRUE)

# pogledamo porazdelitev teh dveh spremenljivk
par(mfrow = c(1, 2))
histNorm(podatki$tradicionalniViri, xlim = c(1, 5), main = "tradicionalni viri", xlab = "obseg energije", ylab = "Frekvenca")
histNorm(podatki$alternativniViri, xlim = c(1, 5), main = "alternativni viri", xlab = "obseg energije", ylab = "Frekvenca")

# pogledamo porazdelitev teh dveh spremenljivk tabelaricno
povzetek <- data.frame(psych::describe(podatki[, c("tradicionalniViri", "alternativniViri")]))
rownames(povzetek) <- c("tradicionalniViri", "alternativniViri")
round(povzetek[, c(2, 3, 4, 5, 8, 9, 10, 11, 12)], 2)

# pogledamo korerelacijo med spremenljivkama Lik. lestvice
# ce imate vec kot 2 spremenljivki, lahko uporabite funkcijo pairs
# vrednosti prej "raztresemo"
tmp <- apply(podatki[, c("tradicionalniViri", "alternativniViri")], 2, jitter, amount = 0.1)
plot(tmp, ylim = c(1, 5), xlim = c(1, 5), xlab = "tradicionalni viri", ylab = "alternativni viri")

cor.test(x = podatki$tradicionalniVir, y = podatki$alternativniViri)

# pogledamo korelacijo med Lik spremenljivkama in starostjo :: podobno lahko naredimo se za ostale Lik. lestvice
plot(podatki$starost, jitter(podatki$alternativniViri, amount = 0.05), xlab = "starost", ylab = "alternativni viri")
cor.test(podatki$starost, podatki$alternativniViri, use = "compl")

plot(podatki$starost, jitter(podatki$tradicionalniViri, amount = 0.05), xlab = "starost", ylab = "tradicionalni viri")
cor.test(podatki$starost, podatki$tradicionalniViri, use = "compl")

# pogledamo, kako se razlikujejo ocene po kategoricnih spremenljivkah
par(mfrow = c(1,2), mar = c(11, 5, 2, 2))
plotmeans(tradicionalniViri ~ spol, data = podatki, ylab = "povprecje", xlab = "", main = "tradicionalni viri", las = 2, cex.axis = 0.7, ylim = c(1, 5))
plotmeans(alternativniViri ~ spol, data = podatki, ylab = "povprecje", xlab = "", main = "alternativni viri", las = 2, cex.axis = 0.7, ylim = c(1, 5))

t.test(podatki$tradicionalniViri ~ podatki$spol)
t.test(podatki$alternativniViri ~ podatki$spol)

par(mfrow = c(1,2), mar = c(11, 5, 2, 2))
plotmeans(tradicionalniViri ~ izobrazba, data = podatki, ylab = "povprecje", xlab = "", main = "tradicionalni viri", las = 2, cex.axis = 0.7, ylim = c(1, 5))
plotmeans(alternativniViri ~ izobrazba, data = podatki, ylab = "povprecje", xlab = "", main = "alternativni viri", las = 2, cex.axis = 0.7, ylim = c(1, 5))

cor.test(podatki$tradicionalniViri, as.numeric(podatki$izob), method = "spearman", use = "com", exact = FALSE)
cor.test(podatki$alternativniViri, as.numeric(podatki$izob), method = "spearman", use = "com", exact = FALSE)

par(mfrow = c(1,2), mar = c(11, 5, 2, 2))
plotmeans(tradicionalniViri ~ sektor, data = podatki, ylab = "povprecje", xlab = "", main = "tradicionalni viri", las = 2, cex.axis = 0.7, ylim = c(1, 5))
plotmeans(alternativniViri ~ sektor, data = podatki, ylab = "povprecje", xlab = "", main = "alternativni viri", las = 2, cex.axis = 0.7, ylim = c(1, 5))

oneway.test(podatki$tradicionalniViri ~ podatki$sektor)
oneway.test(podatki$alternativniViri ~ podatki$sektor)

#######################################################################################
#                            TOCKA 5: GRAF
#######################################################################################
dev.off()

# izberemo spremenljivko
var <- "spol"
imena_spremenljivk <- c("tradicionalniViri", "alternativniViri")
# izracunamo centroide po spolu
(agg <- aggregate(podatki[, imena_spremenljivk], by = list(podatki[, var]), FUN=mean, na.rm = TRUE))
tmp <- apply(podatki[, imena_spremenljivk], 2, jitter, amount = 0.07)
joint <- rbind(tmp, agg[, -1])
# narisemo v 2D prostoru, kot smo se naucili - s funkcijo jitter
# v primeru, da imamo tri spremenljivke, "plot" nadomestimo s "pairs"
pairs(joint,
     #xlab = "tradicionalni viri",
     #ylab = "alternativni viri",
     pch = 16,
     ylim = c(1, 5), xlim = c(0.5, 5.5),
     # nastavimo velikost pik
     cex = c(rep(0.5, nrow(tmp)), rep(2, nrow(agg))),
     # pike pobarvamo glede na spol
     col=c(podatki[, var], agg[,1]))
# dodamo legendo
par(xpd=TRUE)
legend("topleft", legend = agg[,1], pch = 16, col = 1:nrow(agg))
#######################################################################################
#                            TOCKA 5: SHRANIMO PODATKE
#######################################################################################
# Ne pozabite shraniti urejene podatkovne datoteke!
# Potrebovali jo bomo na naslednjih vajah!
# save(podatki, file = "WVSLO_rekodirane")
###############################################
